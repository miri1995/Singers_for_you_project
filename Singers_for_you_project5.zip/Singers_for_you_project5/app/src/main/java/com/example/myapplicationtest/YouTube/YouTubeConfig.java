
package com.example.myapplicationtest.YouTube;

public class YouTubeConfig {

    private static final String API_KEY="AIzaSyCh-7diJlKRcvzPhrR57ojg2Swe0OJaHUE";

    public YouTubeConfig(){

    }

    public static String getApiKey(){
        return API_KEY;
    }
}