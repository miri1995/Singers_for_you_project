package com.example.myapplicationtest.DataBase;

public class DBConfig {

    final String host = "35.225.34.63";
    final String port = "3306";
    final String schema = "dbProject";
    final String user = "root";
    final String password = "0542015460mb";


    public DBConfig() {
    }

    public String getHost() {
        return host;
    }

    public String getPort() {
        return port;
    }

    public String getSchema() {
        return schema;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }
}
